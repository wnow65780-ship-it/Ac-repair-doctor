# APK build from GitHub mobile

1. Upload the complete project folders/files to the repository.
2. Open GitHub -> Actions.
3. Select `Build APK`.
4. Tap `Run workflow`.
5. Wait for the green check.
6. Open the workflow run -> Artifacts -> `AC-Repair-Doctor-debug-apk`.
7. Download the artifact ZIP and extract `app-debug.apk`.

The project includes a GitHub Actions workflow so you do not need Android Studio to create the debug APK.
