package com.acrepairdoctor;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content;
    final int BLUE=Color.rgb(21,101,192), BG=Color.rgb(244,247,251), TEXT=Color.rgb(23,32,51);
    final int MUTED=Color.rgb(100,112,130), GREEN=Color.rgb(24,134,75), ORANGE=Color.rgb(230,125,10);
    SharedPreferences sp;
    String fault="";
    int step=0;
    Uri photoUri=null;

    String[] faults={
        "❄️ Cooling Problem","⚡ Electrical / Power","🧠 PCB / Inverter",
        "🔧 Compressor","💨 Refrigerant / Gas","🌬️ Indoor Unit",
        "🌀 Outdoor Unit / Fan","💧 Water Leakage","📡 Sensor / Communication"
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("cases",MODE_PRIVATE);
        home();
    }

    TextView text(String s,float z,int c,boolean bold){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(c);
        v.setTypeface(null,bold?1:0); return v;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(15); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(BLUE); b.setPadding(12,8,12,8);
        return b;
    }
    void frame(String title,String sub){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(BG);
        LinearLayout h=new LinearLayout(this); h.setOrientation(LinearLayout.VERTICAL); h.setPadding(22,18,22,16);
        h.setBackgroundColor(Color.WHITE);
        h.addView(text("🔧  "+title,27,TEXT,true));
        TextView st=text(sub,15,MUTED,false); st.setPadding(0,5,0,0); h.addView(st);
        r.addView(h,new LinearLayout.LayoutParams(-1,-2));
        ScrollView sv=new ScrollView(this);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,15,18,28);
        sv.addView(content); r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(r);
    }
    void gap(int n){ Space s=new Space(this); content.addView(s,new LinearLayout.LayoutParams(1,n)); }
    TextView card(String s){
        TextView v=text(s,15,TEXT,false); v.setPadding(17,16,17,16); v.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); content.addView(v,p); return v;
    }
    EditText input(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(false);
        e.setPadding(14,8,14,8); e.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58); p.setMargins(0,5,0,5); content.addView(e,p); return e;
    }

    void home(){
        frame("AC Repair Doctor","Complete technician troubleshooting assistant");
        TextView w=text("👨‍🔧 Select AC Problem",20,TEXT,true); w.setPadding(0,4,0,8); content.addView(w);
        GridLayout g=new GridLayout(this); g.setColumnCount(2); content.addView(g,new LinearLayout.LayoutParams(-1,-2));
        for(String f:faults){
            Button b=new Button(this); b.setText(f); b.setAllCaps(false); b.setTextSize(14); b.setTextColor(TEXT); b.setBackgroundColor(Color.WHITE);
            b.setOnClickListener(v->{fault=((Button)v).getText().toString();step=0;diagnosis();});
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0;p.height=125;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(4,4,4,4);g.addView(b,p);
        }
        gap(10);
        Button p=btn("📷  PCB / AC Photo Analysis"); p.setOnClickListener(v->photoScreen()); content.addView(p,new LinearLayout.LayoutParams(-1,56));
        gap(7);
        Button m=btn("📏  Test Measurements"); m.setOnClickListener(v->measureScreen()); content.addView(m,new LinearLayout.LayoutParams(-1,56));
        gap(7);
        Button h=btn("🗂️  Saved Job History"); h.setOnClickListener(v->history()); content.addView(h,new LinearLayout.LayoutParams(-1,56));
        gap(14);
        card("⚠️ Safety: mains power isolate करें. Capacitor/PCB/compressor पर live work केवल trained technician करे.");
    }

    String[] data(){
        if(fault.contains("Cooling")) return new String[]{
            "क्या cooling कम है और airflow normal है?","Filter, blower और evaporator coil साफ/blocked condition check करें.","अगर airflow ठीक है तो coil temperature pattern, refrigerant circuit और outdoor unit verify करें."
        };
        if(fault.contains("Electrical")) return new String[]{
            "क्या AC को सही supply मिल रही है?","Power OFF करके MCB, fuse, cable, terminals और connectors inspect करें.","Live measurement केवल qualified technician करे."
        };
        if(fault.contains("PCB")) return new String[]{
            "PCB पर burn mark, loose connector या damaged component दिख रहा है?","Power OFF करके connectors, tracks, fuse और visible components inspect करें.","Model wiring diagram से connector/function verify करें."
        };
        if(fault.contains("Compressor")) return new String[]{
            "Compressor start नहीं हो रहा या abnormal heat/noise है?","Wiring, start components/drive और compressor terminals की condition verify करें.","Manufacturer specification के अनुसार electrical tests करें."
        };
        if(fault.contains("Refrigerant")) return new String[]{
            "Cooling कम है और coil temperature pattern abnormal है?","Leak signs, coil condition और refrigerant circuit inspect करें.","सिर्फ pressure देखकर gas charge न करें; leak और specified charge method follow करें."
        };
        if(fault.contains("Indoor")) return new String[]{
            "Indoor fan और airflow normal है?","Filter, blower, evaporator coil और drain tray inspect करें.","Airflow restriction मिले तो cleaning/service करें."
        };
        if(fault.contains("Outdoor")) return new String[]{
            "Outdoor fan और condenser airflow normal है?","Condenser coil, fan motor, capacitor/drive और wiring inspect करें.","Fan/coil fault cooling और compressor operation को affect कर सकता है."
        };
        if(fault.contains("Water")) return new String[]{
            "Indoor unit से पानी leak हो रहा है?","Drain tray, drain pipe, slope और blockage check करें.","Drain flow test करके leakage source confirm करें."
        };
        return new String[]{
            "Error code या communication/sensor issue है?","Power OFF करके sensor और communication connectors inspect करें.","Model-specific wiring diagram और sensor specification से verify करें."
        };
    }

    void diagnosis(){
        frame("Diagnosis","Step "+(step+1)+" • "+fault);
        String[] d=data();
        card("❓ "+d[0]);
        card("🧪 TEST\n"+d[1]);
        card("➡️ NEXT\n"+d[2]);
        gap(8);
        if(step<2){
            Button n=btn("NEXT TEST  →"); n.setOnClickListener(v->{step++;diagnosis();});content.addView(n,new LinearLayout.LayoutParams(-1,56));
        } else {
            Button r=btn("✅  GENERATE DIAGNOSIS"); r.setOnClickListener(v->result());content.addView(r,new LinearLayout.LayoutParams(-1,56));
        }
        gap(6); Button b=btn("← Home");b.setOnClickListener(v->home());content.addView(b,new LinearLayout.LayoutParams(-1,54));
    }

    void result(){
        frame("Diagnosis Result",fault);
        card("🔎 PROBABLE FAULT CATEGORY\n"+fault);
        card("✅ INITIAL CHECKLIST COMPLETE\n3 diagnostic stages completed.");
        card("📋 RECOMMENDED ACTION\n1. Safety/power check\n2. Indoor airflow & coil check\n3. Outdoor unit/compressor/fan check\n4. Refrigerant/leak check where applicable\n5. PCB/sensor/communication check");
        card("⚠️ FINAL DECISION\nयह assistant probable causes बताता है. Part replacement या gas charging से पहले actual measurements और manufacturer specification verify करें.");
        String old=sp.getString("history","");
        sp.edit().putString("history",fault+"|"+System.currentTimeMillis()+"\n"+old).apply();
        Button b=btn("🔄 New Diagnosis");b.setOnClickListener(v->home());content.addView(b,new LinearLayout.LayoutParams(-1,56));
    }

    void photoScreen(){
        frame("PCB / AC Photo Analysis","Photo inspection checklist");
        card("📷 Photo select करें. App image को case के साथ reference के लिए रखता है.");
        Button p=btn("📷 Select Photo");p.setOnClickListener(v->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,10);
        });content.addView(p,new LinearLayout.LayoutParams(-1,56));
        gap(8);
        input("AC Brand / Model");
        input("Error Code / Problem");
        card("🔍 VISUAL CHECKLIST\n□ Main power connector\n□ Fuse / protection\n□ Burn marks\n□ Capacitors / power section\n□ IPM / inverter section\n□ Fan connector\n□ Sensor connectors\n□ Communication connector\n□ Loose/oxidized terminals");
        Button b=btn("← Home");b.setOnClickListener(v->home());content.addView(b,new LinearLayout.LayoutParams(-1,56));
    }

    void measureScreen(){
        frame("Test Measurements","Technician measurement record");
        EditText model=input("AC brand / model / tonnage");
        EditText voltage=input("Supply voltage (V)");
        EditText current=input("Compressor current (A)");
        EditText suction=input("Suction pressure (if applicable)");
        EditText temp=input("Pipe / coil temperature (°C)");
        EditText room=input("Room temperature (°C)");
        EditText error=input("Error code");
        gap(6);
        Button a=btn("🔍 Analyze Values");a.setOnClickListener(v->{
            String msg="Values recorded.\n\nCompare voltage, current, pressure and temperature with the exact model manufacturer's specifications. Do not use a generic pressure value as a final diagnosis.";
            new AlertDialog.Builder(this).setTitle("Initial Analysis").setMessage(msg).setPositiveButton("OK",null).show();
        });content.addView(a,new LinearLayout.LayoutParams(-1,56));
        gap(6);Button b=btn("← Home");b.setOnClickListener(v->home());content.addView(b,new LinearLayout.LayoutParams(-1,56));
    }

    void history(){
        frame("Saved Job History","Cases stored on this phone");
        String h=sp.getString("history","");
        if(h.trim().isEmpty()) card("🗂️ अभी कोई saved case नहीं है.");
        else {
            String[] rows=h.split("\n");
            for(String row:rows) if(!row.trim().isEmpty()) card("🧾 "+row.split("\\|")[0]);
            Button c=btn("🗑️ Clear History");c.setOnClickListener(v->{
                sp.edit().remove("history").apply();history();
            });content.addView(c,new LinearLayout.LayoutParams(-1,56));
        }
        gap(6);Button b=btn("← Home");b.setOnClickListener(v->home());content.addView(b,new LinearLayout.LayoutParams(-1,56));
    }

    @Override protected void onActivityResult(int r,int result,Intent data){
        super.onActivityResult(r,result,data);
        if(r==10 && result==RESULT_OK && data!=null){
            photoUri=data.getData();
            Toast.makeText(this,"Photo selected successfully",Toast.LENGTH_SHORT).show();
        }
    }
}
